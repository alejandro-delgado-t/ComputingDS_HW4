# Diabetes Mellitus Prediction Package

This is a package containing multiple functions used to predict the presence of diabetes mellitus.
[GitHub](https://github.com/alejandro-delgado-t/ComputingDS_HW4)
